


---
title: "Sample TL App script"
author: "Jeremy Coyle"
date: "9/1/2017"
output: html_document
---





## Analysis Parameters

```
{"fields": [{"name": "Learners", "value": []}, {"name": "Abar"}], "output_directory": "/tmp/79e0769e-b1fb-4d33-999f-b08fe30446ad", "data": {"nodes": {"A": "parity", "Y": "haz", "W": ["apgar1", "apgar5", "gagebrth", "mage", "meducyrs", "sexn"]}, "type": "csv", "uri": "https://raw.githubusercontent.com/BerkeleyBiostats/tlapp/30821fe37d9fdb2cb645ad2c42f63f1c1644d7c4/cpp.csv"}, "params": {"metalearner": {"learner": "Lrnr_nnls"}, "learners": {"glm_learner": {"learner": "Lrnr_glm_fast"}, "sl_glmnet_learner": {"learner": "Lrnr_pkg_SuperLearner", "params": {"SL_wrapper": "SL.glmnet"}}}}}
```

## Analysis 


```r
# Note for Marc Pare:
# in some sense we might want to separate the part of the script that runs an analysis 
# (computantionally expensive, unlikely to change) from the part of the script that reports the results 
# (runs fast, might change a lot)
# the former would likely be an R script, the latter an Rmd document
# this chunk is the analysis part, the rest is the report part
# just something to think about
library(sl3)
```

```
## Warning: replacing previous import by 'R6::R6Class' when loading 'sl3'
```

```r
library(SuperLearner)
```

```
## Loading required package: nnls
```

```
## Super Learner
```

```
## Version: 2.0-22
```

```
## Package created on 2017-07-18
```

```r
#define task from tlparams specification
cpp <- tlparams$data
cpp[is.na(cpp)] <- 0
covars <- c(unlist(tlparams$data_nodes$W), tlparams$data_nodes$A)
outcome <- tlparams$data_nodes$Y
task <- sl3_Task$new(cpp, covariates = covars, outcome = outcome)

#define learners based on tlparams
learner_from_params <- function(learner){
  Lrnr_factory <- get(learner$learner)
  params <- learner$params
  
  if(is.null(params)){
    params <- list()
  }
  learner <- do.call(Lrnr_factory$new, params)
  
  return(learner)
}

learners <- lapply(tlparams$params$learners, learner_from_params)
metalearner <- learner_from_params(tlparams$params$metalearner)
sl_learner <- Lrnr_sl$new(learners = learners, metalearner = metalearner)
sl_fit <- sl_learner$train(task)
```

```
## Loading required package: glmnet
```

```
## Loading required package: Matrix
```

```
## Loading required package: utils
```

```
## 
## Attaching package: 'utils'
```

```
## The following objects are masked from 'package:Matrix':
## 
##     head, tail
```

```
## Loading required package: foreach
```

```
## Loaded glmnet 2.0-13
```

## Results

Just a sample of some output types


### Coef table

|                                |      Coef|
|:-------------------------------|---------:|
|Lrnr_glm_fast_Cholesky_NULL     | 0.3026758|
|Lrnr_pkg_SuperLearner_SL.glmnet | 0.6133923|

### Coef plot
![plot of chunk coef_plot](figure/coef_plot-1.png)

### Coef text

```
##                                      Coef
## Lrnr_glm_fast_Cholesky_NULL     0.3026758
## Lrnr_pkg_SuperLearner_SL.glmnet 0.6133923
```

### We can also write output to a file

Nothing to see here




